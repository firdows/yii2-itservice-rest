-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- โฮสต์: 127.0.0.1
-- เวลาในการสร้าง: 13 มิ.ย. 2019  10:37น.
-- เวอร์ชั่นของเซิร์ฟเวอร์: 5.5.57-0ubuntu0.14.04.1
-- รุ่นของ PHP: 5.5.9-1ubuntu4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- ฐานข้อมูล: `itservice_db`
--

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- dump ตาราง `location`
--

INSERT INTO `location` (`id`, `code`, `name`) VALUES
(1, 'th', 'Thailand11'),
(2, 'en', 'English'),
(6, '1/1', 'ห้อง 1/1'),
(15, '1/2', 'ห้อง 1/2'),
(31, '91', 'สตูล');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- dump ตาราง `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1538022588),
('m170823_080921_users', 1538022607),
('m170921_160116_news', 1538022607);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `user1`
--

CREATE TABLE IF NOT EXISTS `user1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(200) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- dump ตาราง `user1`
--

INSERT INTO `user1` (`id`, `user_type`, `name`, `username`, `password`) VALUES
(1, 1, 'แอดมิน', 'admin', '123456'),
(2, 0, 'สมชาย  ชาติชาย', 'user1', 'user1'),
(5, 0, 'firdows', 'firdows', '123456'),
(7, 0, 'ทดสอบ', 'test', 'ะำหะ'),
(8, 1, 'ผู้ทดสอบ1', 'test1', '123456');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `user_type` tinyint(1) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- dump ตาราง `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `user_type`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'pSpVt01gdKEZyFkl5Q_qwpUjfBdknT1d', '$2y$13$YwH2Ypjd05c8joWg82dph.7DP.DQyPimFPMkURZBzV5CCHirsK4hi', NULL, 'admin@itservice.local', 10, 1, 1538024794, 1538024794),
(3, 'test', 'test', 'IzaaKJ0_gNzfR7BT9kpNd_AABQa_gPND', '$2y$13$hiY8C.zi039zXFxU5ii9FuqUd2G4WmFlxR1K1oETWFhLRTj/bKG32', NULL, 'test@test.com', 10, 0, 1538102392, 1538102392),
(6, 'xxx', 'xxx', 'hT0KgFy-glTDhMoWsA4F1eQBDfojUXbF', '$2y$13$g1sKTVXgYKie3akkkQjMreO2f4vdh1muVHZWW0YjGWQJUTJRjDaCu', NULL, 'ahamad.jedu1@gmail.com', 10, 1, 1538103312, 1538103312),
(8, 'พี่บ่าว', 'kuakling', '9IffHNfPSwIA9jg7RQslhW0CU_bftKfu', '$2y$13$mTKdVS6RI.528ABSmrw7GOFi7o02t2hxGZ1o8vOYjv35hvzNoADAm', NULL, 'kuakling@gmai.com', 10, 0, 1538146925, 1538146925);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `work`
--

CREATE TABLE IF NOT EXISTS `work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_date` date NOT NULL,
  `doc_time` varchar(5) NOT NULL,
  `location_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `detail` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `status_date` date DEFAULT NULL,
  `work_detail` text,
  `work_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- dump ตาราง `work`
--

INSERT INTO `work` (`id`, `doc_date`, `doc_time`, `location_id`, `title`, `detail`, `phone`, `status`, `status_date`, `work_detail`, `work_user_id`, `user_id`) VALUES
(2, '2018-09-28', '10:04', 6, 'ไม่รู้เรื่อง', 'sdf', 'sdfsdf', 0, NULL, NULL, NULL, 6),
(17, '2018-09-28', '12:13', 2, 'คอมเสีย', 'คอมเสีย', 'หำดำหด', 0, NULL, NULL, NULL, 6),
(18, '2018-09-28', '12:20', 15, 'โต๊ะมีปัญหา', 'โต๊ะมีปัญหา', '123456', 0, NULL, NULL, NULL, 6),
(19, '2018-09-28', '15:16', 31, 'รถเสีย', 'สตาร์ทไม่ติด', '085697413', 0, NULL, NULL, NULL, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
